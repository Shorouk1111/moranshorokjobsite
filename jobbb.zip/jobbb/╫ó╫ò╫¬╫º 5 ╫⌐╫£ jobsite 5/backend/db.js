const mysql = require('mysql2');

// First connect without database to create it if needed
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: ''
});

// Create database if it doesn't exist
connection.query('CREATE DATABASE IF NOT EXISTS jobportal', (err) => {
  if (err) {
    console.error('Error creating database:', err);
  } else {
    console.log('Database jobportal ready');
  }
  connection.end();
});

// Now connect with the database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'jobportal'
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

module.exports = db;
