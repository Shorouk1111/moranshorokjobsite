const express = require('express');
const cors = require('cors');
const db = require('./db');
const { register, login, verifyToken, requestPasswordReset, resetPassword } = require('./auth');
const nodemailer = require('nodemailer');
require('dotenv').config();

// Email configuration
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Verify email configuration
if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
  console.warn('WARNING: Email credentials are not properly configured. Password reset emails will not work.');
  console.warn('Please set EMAIL_USER and EMAIL_PASS in your .env file.');
}

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Authentication Routes
app.post('/api/auth/register', (req, res) => {
  console.log('Registration request received:', req.body);
  register(req, res);
});

app.post('/api/auth/login', (req, res) => {
  console.log('Login request received:', req.body);
  login(req, res);
});

// Password Reset Routes
app.post('/api/auth/forgot-password', (req, res) => {
  console.log('Password reset request received for email:', req.body.email);
  requestPasswordReset(req, res);
});

app.post('/api/auth/reset-password', (req, res) => {
  console.log('Password reset attempt with token');
  resetPassword(req, res);
});

// Get user profile with details (role-based)
app.get('/api/auth/profile', verifyToken, (req, res) => {
  // First get user info with role
  const userQuery = `
    SELECT u.id, u.full_name, u.email, u.created_at, r.role_name
    FROM users u
    LEFT JOIN roles r ON u.role_id = r.role_id
    WHERE u.id = ?
  `;

  db.query(userQuery, [req.user.userId], (err, userResults) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (userResults.length === 0) {
      return res.status(404).json({ message: 'משתמש לא נמצא' });
    }

    const user = userResults[0];
    const roleName = user.role_name;

    // Get role-specific profile
    let profileQuery = '';
    let profileTable = '';

    if (roleName === 'worker') {
      profileTable = 'worker_profiles';
      profileQuery = `
        SELECT * FROM ${profileTable} WHERE user_id = ?
      `;
    } else if (roleName === 'employer') {
      profileTable = 'employer_profiles';
      profileQuery = `
        SELECT * FROM ${profileTable} WHERE user_id = ?
      `;
    } else if (roleName === 'admin') {
      profileTable = 'admin_profiles';
      profileQuery = `
        SELECT * FROM ${profileTable} WHERE user_id = ?
      `;
    }

    if (profileQuery) {
      db.query(profileQuery, [req.user.userId], (err, profileResults) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }

        const profile = profileResults.length > 0 ? profileResults[0] : null;
        res.json({
          ...user,
          profile: profile
        });
      });
    } else {
      res.json(user);
    }
  });
});

// Create or update worker profile
app.post('/api/worker/profile', verifyToken, (req, res) => {
  const { phone, address, skills, experience_years, education, preferred_job_type, preferred_location, salary_expectation, cv_file } = req.body;

  const checkQuery = 'SELECT id FROM worker_profiles WHERE user_id = ?';
  db.query(checkQuery, [req.user.userId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (results.length > 0) {
      const updateQuery = `
        UPDATE worker_profiles SET 
        phone = ?, address = ?, skills = ?, experience_years = ?, 
        education = ?, preferred_job_type = ?, preferred_location = ?, salary_expectation = ?, cv_file = ?
        WHERE user_id = ?
      `;
      db.query(updateQuery, [phone, address, skills, experience_years, education, preferred_job_type, preferred_location, salary_expectation, cv_file, req.user.userId], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל עובד עודכן בהצלחה' });
      });
    } else {
      const insertQuery = `
        INSERT INTO worker_profiles 
        (user_id, phone, address, skills, experience_years, education, preferred_job_type, preferred_location, salary_expectation, cv_file)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      db.query(insertQuery, [req.user.userId, phone, address, skills, experience_years, education, preferred_job_type, preferred_location, salary_expectation, cv_file], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל עובד נוצר בהצלחה' });
      });
    }
  });
});

// Create or update employer profile
app.post('/api/employer/profile', verifyToken, (req, res) => {
  const { company_name, company_description, industry, company_size, website, phone, address, logo_file } = req.body;

  const checkQuery = 'SELECT id FROM employer_profiles WHERE user_id = ?';
  db.query(checkQuery, [req.user.userId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (results.length > 0) {
      const updateQuery = `
        UPDATE employer_profiles SET 
        company_name = ?, company_description = ?, industry = ?, company_size = ?, 
        website = ?, phone = ?, address = ?, logo_file = ?
        WHERE user_id = ?
      `;
      db.query(updateQuery, [company_name, company_description, industry, company_size, website, phone, address, logo_file, req.user.userId], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל מעסיק עודכן בהצלחה' });
      });
    } else {
      const insertQuery = `
        INSERT INTO employer_profiles 
        (user_id, company_name, company_description, industry, company_size, website, phone, address, logo_file)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      db.query(insertQuery, [req.user.userId, company_name, company_description, industry, company_size, website, phone, address, logo_file], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל מעסיק נוצר בהצלחה' });
      });
    }
  });
});

// Create or update admin profile
app.post('/api/admin/profile', verifyToken, (req, res) => {
  const { department, permissions, phone } = req.body;

  const checkQuery = 'SELECT id FROM admin_profiles WHERE user_id = ?';
  db.query(checkQuery, [req.user.userId], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (results.length > 0) {
      const updateQuery = `
        UPDATE admin_profiles SET 
        department = ?, permissions = ?, phone = ?
        WHERE user_id = ?
      `;
      db.query(updateQuery, [department, permissions, phone, req.user.userId], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל מנהל עודכן בהצלחה' });
      });
    } else {
      const insertQuery = `
        INSERT INTO admin_profiles 
        (user_id, department, permissions, phone)
        VALUES (?, ?, ?, ?)
      `;
      db.query(insertQuery, [req.user.userId, department, permissions, phone], (err, results) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'פרופיל מנהל נוצר בהצלחה' });
      });
    }
  });
});

// Get suggested jobs for user based on profile
app.get('/api/jobs/suggested', verifyToken, (req, res) => {
  const query = `
    SELECT j.*, ep.company_name, ep.industry
    FROM jobs j
    LEFT JOIN employer_profiles ep ON j.employer_id = ep.user_id
    LEFT JOIN worker_profiles wp ON wp.user_id = ?
    WHERE j.status = 'active'
      AND (wp.preferred_job_type IS NULL OR j.job_type LIKE CONCAT('%', wp.preferred_job_type, '%'))
      AND (wp.preferred_location IS NULL OR j.location LIKE CONCAT('%', wp.preferred_location, '%'))
    ORDER BY j.created_at DESC
    LIMIT 10
  `;
  db.query(query, [req.user.userId], (err, results) => {
    if (err) {
      console.error('Error fetching suggested jobs:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.json(results);
  });
});

// Apply for a job
app.post('/api/jobs/:jobId/apply', verifyToken, (req, res) => {
  const jobId = req.params.jobId;
  const workerId = req.user.userId;

  // Check if user has worker role
  const checkRoleQuery = `
    SELECT r.role_name 
    FROM users u 
    JOIN roles r ON u.role_id = r.role_id 
    WHERE u.id = ?
  `;

  db.query(checkRoleQuery, [workerId], (err, roleResults) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (roleResults.length === 0 || roleResults[0].role_name !== 'worker') {
      return res.status(403).json({ error: 'Only workers can apply for jobs' });
    }

    // Check if already applied
    const checkApplicationQuery = 'SELECT id FROM job_applications WHERE job_id = ? AND worker_id = ?';
    db.query(checkApplicationQuery, [jobId, workerId], (err, existingResults) => {
      if (err) {
        return res.status(500).json({ error: 'Database error' });
      }

      if (existingResults.length > 0) {
        return res.status(400).json({ error: 'You have already applied for this job' });
      }

      // Create application
      const insertApplicationQuery = `
        INSERT INTO job_applications (job_id, worker_id, status, applied_at)
        VALUES (?, ?, 'pending', NOW())
      `;

      db.query(insertApplicationQuery, [jobId, workerId], (err, results) => {
        if (err) {
          console.error('Error creating application:', err);
          return res.status(500).json({ error: 'Failed to submit application' });
        }

        res.json({
          message: 'Application submitted successfully!',
          applicationId: results.insertId
        });
      });
    });
  });
});

// Get worker's job applications
app.get('/api/worker/applications', verifyToken, (req, res) => {
  const query = `
    SELECT ja.*, j.title, j.company_name, j.location, j.salary_min, j.salary_max
    FROM job_applications ja
    JOIN jobs j ON ja.job_id = j.id
    WHERE ja.worker_id = ?
    ORDER BY ja.applied_at DESC
  `;

  db.query(query, [req.user.userId], (err, results) => {
    if (err) {
      console.error('Error fetching applications:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.json(results);
  });
});

// Job posting endpoint for employers
app.post('/api/employer/jobs', verifyToken, (req, res) => {
  const { title, description, requirements, salary_min, salary_max, location, job_type, category } = req.body;

  // Get employer profile to get company info
  const getEmployerQuery = 'SELECT company_name FROM employer_profiles WHERE user_id = ?';
  db.query(getEmployerQuery, [req.user.userId], (err, employerResults) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (employerResults.length === 0) {
      return res.status(400).json({ error: 'Employer profile not found. Please create your company profile first.' });
    }

    const company_name = employerResults[0].company_name;

    const insertJobQuery = `
      INSERT INTO jobs (title, description, requirements, salary_min, salary_max, 
                       location, job_type, category, company_name, employer_id, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
    `;

    db.query(insertJobQuery, [
      title, description, requirements, salary_min, salary_max,
      location, job_type, category, company_name, req.user.userId
    ], (err, results) => {
      if (err) {
        console.error('Error creating job:', err);
        return res.status(500).json({ error: 'Failed to create job' });
      }

      res.json({
        message: 'Job posted successfully!',
        jobId: results.insertId
      });
    });
  });
});

// Get jobs posted by employer
app.get('/api/employer/jobs', verifyToken, (req, res) => {
  const query = `
    SELECT j.*, COUNT(ja.id) as application_count
    FROM jobs j
    LEFT JOIN job_applications ja ON j.id = ja.job_id
    WHERE j.employer_id = ?
    GROUP BY j.id
    ORDER BY j.created_at DESC
  `;

  db.query(query, [req.user.userId], (err, results) => {
    if (err) {
      console.error('Error fetching employer jobs:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.json(results);
  });
});

// Get all active jobs for workers
app.get('/api/jobs', (req, res) => {
  const query = `
    SELECT j.*, ep.company_name, ep.industry
    FROM jobs j
    LEFT JOIN employer_profiles ep ON j.employer_id = ep.user_id
    WHERE j.status = 'active'
    ORDER BY j.created_at DESC
    LIMIT 50
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching jobs:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.json(results);
  });
});

// Job search endpoint
app.get('/api/jobs/search', (req, res) => {
  const { keyword, location, category, type } = req.query;

  let query = `
    SELECT j.*, c.CategoryName, ct.CityName, jt.TypeName, e.CompanyName 
    FROM job j
    LEFT JOIN category c ON j.CategoryID = c.CategoryID
    LEFT JOIN city ct ON j.CityID = ct.CityID
    LEFT JOIN jobtype jt ON j.TypeID = jt.TypeID
    LEFT JOIN employer e ON j.EmployerID = e.EmployerID
    WHERE 1=1
  `;

  const params = [];

  if (keyword) {
    query += ' AND (j.JobTitle LIKE ? OR j.JobDescription LIKE ? OR e.CompanyName LIKE ?)';
    params.push(`%${keyword}%`, `%${keyword}%`, `%${keyword}%`);
  }

  if (location) {
    query += ' AND ct.CityName LIKE ?';
    params.push(`%${location}%`);
  }

  if (category) {
    query += ' AND c.CategoryName LIKE ?';
    params.push(`%${category}%`);
  }

  if (type) {
    query += ' AND jt.TypeName LIKE ?';
    params.push(`%${type}%`);
  }

  query += ' ORDER BY j.PostedDate DESC LIMIT 20';

  db.query(query, params, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Routes

// Get all candidates
app.get('/api/candidates', (req, res) => {
  const query = 'SELECT * FROM candidate';
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Get candidate by ID
app.get('/api/candidates/:id', (req, res) => {
  const query = 'SELECT * FROM candidate WHERE CandidateID = ?';
  db.query(query, [req.params.id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'Candidate not found' });
    }
    res.json(results[0]);
  });
});

// Create new candidate
app.post('/api/candidates', (req, res) => {
  const { FullName, Phone, Email, Address, Education, Skills } = req.body;
  const query = 'INSERT INTO candidate (FullName, Phone, Email, Address, Education, Skills) VALUES (?, ?, ?, ?, ?, ?)';

  db.query(query, [FullName, Phone, Email, Address, Education, Skills], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({
      message: 'Candidate created successfully',
      candidateId: results.insertId
    });
  });
});

// Update candidate
app.put('/api/candidates/:id', (req, res) => {
  const { FullName, Phone, Email, Address, Education, Skills } = req.body;
  const query = 'UPDATE candidate SET FullName = ?, Phone = ?, Email = ?, Address = ?, Education = ?, Skills = ? WHERE CandidateID = ?';

  db.query(query, [FullName, Phone, Email, Address, Education, Skills, req.params.id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Candidate not found' });
    }
    res.json({ message: 'Candidate updated successfully' });
  });
});

// Delete candidate
app.delete('/api/candidates/:id', (req, res) => {
  const query = 'DELETE FROM candidate WHERE CandidateID = ?';
  db.query(query, [req.params.id], (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Candidate not found' });
    }
    res.json({ message: 'Candidate deleted successfully' });
  });
});

// Get all jobs
app.get('/api/jobs', (req, res) => {
  const query = `
    SELECT j.*, c.CategoryName, ct.CityName, jt.TypeName, e.CompanyName 
    FROM job j
    LEFT JOIN category c ON j.CategoryID = c.CategoryID
    LEFT JOIN city ct ON j.CityID = ct.CityID
    LEFT JOIN jobtype jt ON j.TypeID = jt.TypeID
    LEFT JOIN employer e ON j.EmployerID = e.EmployerID
  `;
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Get all categories
app.get('/api/categories', (req, res) => {
  const query = 'SELECT * FROM category';
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Get all cities
app.get('/api/cities', (req, res) => {
  const query = 'SELECT * FROM city';
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

// Create roles table if it doesn't exist
const createRolesTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS roles (
      role_id int(11) NOT NULL AUTO_INCREMENT,
      role_name varchar(50) UNIQUE NOT NULL,
      PRIMARY KEY (role_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating roles table:', err);
    } else {
      console.log('Roles table ready');
      // Insert default roles
      const insertRoles = `
        INSERT IGNORE INTO roles (role_name) VALUES 
        ('admin'), ('worker'), ('employer')
      `;
      db.query(insertRoles, (err, results) => {
        if (err) {
          console.error('Error inserting roles:', err);
        } else {
          console.log('Default roles inserted');
        }
      });
    }
  });
};

// Create users table if it doesn't exist
const createUsersTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS users (
      id int(11) NOT NULL AUTO_INCREMENT,
      full_name varchar(100) NOT NULL,
      email varchar(100) NOT NULL UNIQUE,
      password varchar(255) NOT NULL,
      role_id int(11),
      created_at timestamp DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      FOREIGN KEY (role_id) REFERENCES roles(role_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating users table:', err);
    } else {
      console.log('Users table ready');
    }
  });
};

// Create worker profiles table
const createWorkerProfilesTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS worker_profiles (
      id int(11) NOT NULL AUTO_INCREMENT,
      user_id int(11) NOT NULL,
      phone varchar(20),
      address varchar(255),
      skills text,
      experience_years int,
      education varchar(255),
      preferred_job_type varchar(100),
      preferred_location varchar(100),
      salary_expectation varchar(50),
      cv_file varchar(255),
      created_at timestamp DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating worker_profiles table:', err);
    } else {
      console.log('Worker profiles table ready');
    }
  });
};

// Create employer profiles table
const createEmployerProfilesTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS employer_profiles (
      id int(11) NOT NULL AUTO_INCREMENT,
      user_id int(11) NOT NULL,
      company_name varchar(255) NOT NULL,
      company_description text,
      industry varchar(100),
      company_size varchar(50),
      website varchar(255),
      phone varchar(20),
      address varchar(255),
      logo_file varchar(255),
      created_at timestamp DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating employer_profiles table:', err);
    } else {
      console.log('Employer profiles table ready');
    }
  });
};

// Create admin profiles table
const createAdminProfilesTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS admin_profiles (
      id int(11) NOT NULL AUTO_INCREMENT,
      user_id int(11) NOT NULL,
      department varchar(100),
      permissions text,
      phone varchar(20),
      created_at timestamp DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating admin_profiles table:', err);
    } else {
      console.log('Admin profiles table ready');
    }
  });
};

// Create jobs table
const createJobsTable = () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS jobs (
      id int(11) NOT NULL AUTO_INCREMENT,
      title varchar(255) NOT NULL,
      description text,
      requirements text,
      salary_min decimal(10,2),
      salary_max decimal(10,2),
      location varchar(255),
      job_type varchar(100),
      category varchar(100),
      company_name varchar(255),
      employer_id int(11) NOT NULL,
      status enum('active', 'closed', 'draft') DEFAULT 'active',
      created_at timestamp DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id),
      FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
  `;

  db.query(createTableQuery, (err, results) => {
    if (err) {
      console.error('Error creating jobs table:', err);
    } else {
      console.log('Jobs table ready');
    }
  });
};

// Create job applications table
const createJobApplicationsTable = () => {
  const query = `
    CREATE TABLE IF NOT EXISTS job_applications (
      application_id INT AUTO_INCREMENT PRIMARY KEY,
      job_id INT NOT NULL,
      worker_id INT NOT NULL,
      employer_id INT NOT NULL,
      status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
      applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
      FOREIGN KEY (worker_id) REFERENCES users(user_id) ON DELETE CASCADE,
      FOREIGN KEY (employer_id) REFERENCES users(user_id) ON DELETE CASCADE
    )`;

  db.query(query, (err) => {
    if (err) {
      console.error('Error creating job_applications table:', err);
    } else {
      console.log('Job applications table created or already exists');
    }
  });
};

// Create password reset tokens table
const createPasswordResetTokensTable = () => {
  const query = `
    CREATE TABLE IF NOT EXISTS password_reset_tokens (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      token VARCHAR(255) NOT NULL,
      expires_at DATETIME NOT NULL,
      used BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`;

  db.query(query, (err) => {
    if (err) {
      console.error('Error creating password_reset_tokens table:', err);
    } else {
      console.log('Password reset tokens table created or already exists');
    }
  });
};

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  // Create tables on startup
  createRolesTable();
  createUsersTable();
  createWorkerProfilesTable();
  createEmployerProfilesTable();
  createAdminProfilesTable();
  createJobsTable();
  createJobApplicationsTable();
  createPasswordResetTokensTable();
  
  // Insert default roles if they don't exist
  const roles = [
    { role_id: 1, role_name: 'admin', description: 'Administrator' },
    { role_id: 2, role_name: 'employer', description: 'Employer' },
    { role_id: 3, role_name: 'worker', description: 'Job Seeker' }
  ];

  roles.forEach(role => {
    const query = 'INSERT IGNORE INTO roles (role_id, role_name, description) VALUES (?, ?, ?)';
    db.query(query, [role.role_id, role.role_name, role.description], (err) => {
      if (err) console.error(`Error inserting role ${role.role_name}:`, err);
    });
  });
});

module.exports = app;
