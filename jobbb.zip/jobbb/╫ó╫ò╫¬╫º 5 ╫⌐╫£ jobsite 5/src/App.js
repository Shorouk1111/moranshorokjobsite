// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import UpgradeCV from './pages/UpgradeCV';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';
import FreeSearch from './pages/FreeSearch';
import InterviewMistakes from './pages/InterviewMistakes';
import InterviewDress from './pages/InterviewDress';
import CvWriting from './pages/CvWriting';
import InterviewTips from './pages/InterviewTips';
import PersonalGuidance from './pages/PersonalGuidance';
import SalaryComparison from './pages/SalaryComparison';
import WorkerDashboard from './pages/WorkerDashboard';
import EmployerDashboard from './pages/EmployerDashboard';
import AdminDashboard from './pages/AdminDashboard';
import './pages/auth/Auth.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/upgrade-cv" element={<UpgradeCV />} />
        <Route path="/free-search" element={<FreeSearch />} />
        <Route path="/articles/interview-mistakes" element={<InterviewMistakes />} />
        <Route path="/articles/interview-dress" element={<InterviewDress />} />
        <Route path="/articles/cv-writing" element={<CvWriting />} />
        <Route path="/articles/interview-tips" element={<InterviewTips />} />
        <Route path="/personal-guidance" element={<PersonalGuidance />} />
        <Route path="/salary-comparison" element={<SalaryComparison />} />
        <Route path="/worker-dashboard" element={<WorkerDashboard />} />
        <Route path="/employer-dashboard" element={<EmployerDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
