import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  return (
    <nav className="top-navbar">
      <div className="logo">
        <Link to="/">הצעד הבא בקריירה</Link>
      </div>
      <div className="auth-buttons">
        <Link to="/login">
          <button className="login-btn">התחברות</button>
        </Link>
        <Link to="/register">
          <button className="signup-btn">הרשמה</button>
        </Link>
      </div>
    </nav>
  );
}
