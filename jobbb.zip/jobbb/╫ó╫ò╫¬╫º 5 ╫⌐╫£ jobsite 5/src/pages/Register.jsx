import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaUser, FaEnvelope, FaLock, FaUserPlus } from 'react-icons/fa';
import './Register.css';

export default function Register() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // כאן יהיה הטיפול בהרשמה
    console.log('נתוני הרשמה:', formData);
  };

  return (
    <div className="register-page">
      <div className="register-container">
        <h1>הרשמה</h1>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="fullName">שם מלא</label>
            <div className="input-container">
              <FaUser className="input-icon" />
              <input
                type="text"
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                required
                placeholder="הכנס את שמך המלא"
              />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="email">אימייל</label>
            <div className="input-container">
              <FaEnvelope className="input-icon" />
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="הכנס את האימייל שלך"
              />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="password">סיסמה</label>
            <div className="input-container">
              <FaLock className="input-icon" />
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="בחר סיסמה"
                minLength="8"
              />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="confirmPassword">אימות סיסמה</label>
            <div className="input-container">
              <FaLock className="input-icon" />
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                required
                placeholder="הכנס את הסיסמה שוב"
              />
            </div>
          </div>
          <button type="submit" className="submit-btn">
            <FaUserPlus className="btn-icon" />
            הירשם
          </button>
        </form>
        <div className="login-link">
          כבר יש לך חשבון?{' '}
          <Link to="/login">התחבר כאן</Link>
        </div>
      </div>
    </div>
  );
}
