import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'worker'
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      alert('הסיסמאות אינן תואמות');
      return;
    }

    try {
      const fullName = `${formData.firstName} ${formData.lastName}`;
      
      const response = await fetch('http://localhost:5000/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fullName: fullName,
          email: formData.email,
          password: formData.password,
          role: formData.role
        })
      });

      const data = await response.json();

      if (response.ok) {
        alert('הרשמה בוצעה בהצלחה!');
        // Store token and user data
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        // Role-based redirect
        const userRole = data.user.role;
        if (userRole === 'admin') {
          window.location.href = '/admin-dashboard';
        } else if (userRole === 'employer') {
          window.location.href = '/employer-dashboard';
        } else {
          window.location.href = '/worker-dashboard';
        }
        console.log('Registration successful:', data);
      } else {
        alert(data.message || 'שגיאה בהרשמה');
      }
    } catch (error) {
      console.error('Registration error:', error);
      alert('שגיאה בחיבור לשרת');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2>הרשמה</h2>
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="firstName">שם פרטי</label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="lastName">שם משפחה</label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">אימייל</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              dir="ltr"
            />
          </div>
          <div className="form-group">
            <label htmlFor="role">סוג משתמש</label>
            <select
              id="role"
              name="role"
              value={formData.role}
              onChange={handleChange}
              required
            >
              <option value="worker">עובד/מחפש עבודה</option>
              <option value="employer">מעסיק/חברה</option>
              <option value="admin">מנהל מערכת</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="password">סיסמה</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              dir="ltr"
            />
          </div>
          <div className="form-group">
            <label htmlFor="confirmPassword">אימות סיסמה</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
              dir="ltr"
            />
          </div>
          <button type="submit" className="auth-button">הרשם</button>
          <div className="auth-links">
            <Link to="/login">יש לך כבר חשבון? התחבר כאן</Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
