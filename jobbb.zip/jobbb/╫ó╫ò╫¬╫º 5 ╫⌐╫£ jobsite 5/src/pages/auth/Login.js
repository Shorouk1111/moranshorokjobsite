import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password
        })
      });

      const data = await response.json();

      if (response.ok) {
        alert('התחברות בוצעה בהצלחה!');
        // Store token and user data
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        // Role-based redirect
        const userRole = data.user.role;
        if (userRole === 'admin') {
          window.location.href = '/admin-dashboard';
        } else if (userRole === 'employer') {
          window.location.href = '/employer-dashboard';
        } else {
          window.location.href = '/worker-dashboard';
        }
        console.log('Login successful:', data);
      } else {
        alert(data.message || 'שגיאה בהתחברות');
      }
    } catch (error) {
      console.error('Login error:', error);
      alert('שגיאה בחיבור לשרת');
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <h2>התחברות</h2>
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">אימייל</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              dir="ltr"
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">סיסמה</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              dir="ltr"
            />
          </div>
          <button type="submit" className="auth-button">התחבר</button>
          <div className="auth-links">
            <Link to="/forgot-password">שכחת סיסמה?</Link>
            <Link to="/register">אין לך חשבון? הירשם כאן</Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
