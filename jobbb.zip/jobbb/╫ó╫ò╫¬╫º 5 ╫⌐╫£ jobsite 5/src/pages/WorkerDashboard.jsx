import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './WorkerDashboard.css';

const WorkerDashboard = () => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [suggestedJobs, setSuggestedJobs] = useState([]);
  const [allJobs, setAllJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [profileData, setProfileData] = useState({
    phone: '',
    address: '',
    skills: '',
    experience_years: '',
    education: '',
    preferred_job_type: '',
    preferred_location: '',
    salary_expectation: '',
    cv_file: ''
  });

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }

    // Fetch user profile
    fetchProfile();
    fetchSuggestedJobs();
    fetchAllJobs();
    fetchApplications();
  }, []);

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/auth/profile', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setProfile(data.profile);
        if (data.profile) {
          setProfileData(data.profile);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const fetchSuggestedJobs = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/jobs/suggested', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setSuggestedJobs(data);
      }
    } catch (error) {
      console.error('Error fetching suggested jobs:', error);
    }
  };

  const fetchAllJobs = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/jobs');
      if (response.ok) {
        const data = await response.json();
        setAllJobs(data);
      }
    } catch (error) {
      console.error('Error fetching all jobs:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/worker/applications', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setApplications(data);
      }
    } catch (error) {
      console.error('Error fetching applications:', error);
    }
  };

  const handleJobApplication = async (jobId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:5000/api/jobs/${jobId}/apply`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        alert('מועמדות הוגשה בהצלחה!');
        fetchApplications(); // Refresh applications
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'שגיאה בהגשת המועמדות');
      }
    } catch (error) {
      console.error('Error applying for job:', error);
      alert('שגיאה בחיבור לשרת');
    }
  };

  const isJobApplied = (jobId) => {
    return applications.some(app => app.job_id === jobId);
  };

  const handleProfileChange = (e) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/worker/profile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(profileData)
      });

      if (response.ok) {
        alert('פרופיל נשמר בהצלחה!');
        setShowProfileForm(false);
        fetchProfile();
        fetchSuggestedJobs();
        fetchAllJobs();
        fetchApplications();
      } else {
        alert('שגיאה בשמירת הפרופיל');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      alert('שגיאה בחיבור לשרת');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  };

  return (
    <div className="worker-dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <div className="header-left">
            <Link to="/" className="home-link">🏠 דף הבית</Link>
            <h1>לוח בקרה - מחפש עבודה</h1>
          </div>
          <div className="user-info">
            <span>שלום, {user?.fullName}</span>
            <button onClick={handleLogout} className="logout-btn">התנתק</button>
          </div>
        </div>
      </header>

      <div className="dashboard-content">
        <div className="sidebar">
          <div className="profile-section">
            <h3>הפרופיל שלי</h3>
            {profile ? (
              <div className="profile-info">
                <p><strong>טלפון:</strong> {profile.phone || 'לא הוזן'}</p>
                <p><strong>כתובת:</strong> {profile.address || 'לא הוזנה'}</p>
                <p><strong>כישורים:</strong> {profile.skills || 'לא הוזנו'}</p>
                <p><strong>ניסיון:</strong> {profile.experience_years || 0} שנים</p>
                <button 
                  onClick={() => setShowProfileForm(true)}
                  className="edit-profile-btn"
                >
                  ערוך פרופיל
                </button>
              </div>
            ) : (
              <div className="no-profile">
                <p>לא נמצא פרופיל</p>
                <button 
                  onClick={() => setShowProfileForm(true)}
                  className="create-profile-btn"
                >
                  צור פרופיל
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="main-content">
          <div className="suggested-jobs">
            <h2>משרות מומלצות עבורך</h2>
            <div className="jobs-list">
              {suggestedJobs.length > 0 ? (
                suggestedJobs.map(job => (
                  <div key={job.id} className="job-card">
                    <h3>{job.title}</h3>
                    <p className="company">{job.company_name}</p>
                    <p className="location">{job.location}</p>
                    <p className="salary">₪{job.salary_min?.toLocaleString()} - ₪{job.salary_max?.toLocaleString()}</p>
                    <button 
                      className={`apply-btn ${isJobApplied(job.id) ? 'applied' : ''}`}
                      onClick={() => handleJobApplication(job.id)}
                      disabled={isJobApplied(job.id)}
                    >
                      {isJobApplied(job.id) ? 'הוגשה מועמדות' : 'הגש מועמדות'}
                    </button>
                  </div>
                ))
              ) : (
                <p>אין משרות מומלצות כרגע</p>
              )}
            </div>
          </div>

          <div className="all-jobs">
            <h2>כל המשרות הזמינות ({allJobs.length})</h2>
            <div className="jobs-grid">
              {allJobs.length > 0 ? (
                allJobs.map(job => (
                  <div key={job.id} className="job-card-large">
                    <div className="job-header">
                      <h3>{job.title}</h3>
                      <span className="job-type">{job.job_type}</span>
                    </div>
                    <div className="job-company">
                      <strong>{job.company_name}</strong>
                      {job.industry && <span className="industry"> • {job.industry}</span>}
                    </div>
                    <p className="job-location">📍 {job.location}</p>
                    <p className="job-category">🏷️ {job.category}</p>
                    {job.salary_min && job.salary_max && (
                      <p className="job-salary">💰 ₪{job.salary_min.toLocaleString()} - ₪{job.salary_max.toLocaleString()}</p>
                    )}
                    <div className="job-description">
                      <p>{job.description?.substring(0, 150)}...</p>
                    </div>
                    <div className="job-footer">
                      <span className="job-date">
                        {new Date(job.created_at).toLocaleDateString('he-IL')}
                      </span>
                      <button 
                        className={`apply-btn ${isJobApplied(job.id) ? 'applied' : ''}`}
                        onClick={() => handleJobApplication(job.id)}
                        disabled={isJobApplied(job.id)}
                      >
                        {isJobApplied(job.id) ? 'הוגשה מועמדות' : 'הגש מועמדות'}
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="no-jobs">
                  <p>אין משרות זמינות כרגע</p>
                  <p>חזור מאוחר יותר לעדכונים</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {showProfileForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2>עריכת פרופיל</h2>
              <button 
                onClick={() => setShowProfileForm(false)}
                className="close-btn"
              >
                ×
              </button>
            </div>
            <form onSubmit={handleProfileSubmit} className="profile-form">
              <div className="form-group">
                <label>טלפון:</label>
                <input
                  type="tel"
                  name="phone"
                  value={profileData.phone}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>כתובת:</label>
                <input
                  type="text"
                  name="address"
                  value={profileData.address}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>כישורים:</label>
                <textarea
                  name="skills"
                  value={profileData.skills}
                  onChange={handleProfileChange}
                  rows="3"
                />
              </div>
              <div className="form-group">
                <label>שנות ניסיון:</label>
                <input
                  type="number"
                  name="experience_years"
                  value={profileData.experience_years}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>השכלה:</label>
                <input
                  type="text"
                  name="education"
                  value={profileData.education}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>סוג עבודה מועדף:</label>
                <input
                  type="text"
                  name="preferred_job_type"
                  value={profileData.preferred_job_type}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>מיקום מועדף:</label>
                <input
                  type="text"
                  name="preferred_location"
                  value={profileData.preferred_location}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-group">
                <label>ציפיות שכר:</label>
                <input
                  type="text"
                  name="salary_expectation"
                  value={profileData.salary_expectation}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="save-btn">שמור</button>
                <button 
                  type="button" 
                  onClick={() => setShowProfileForm(false)}
                  className="cancel-btn"
                >
                  ביטול
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkerDashboard;
