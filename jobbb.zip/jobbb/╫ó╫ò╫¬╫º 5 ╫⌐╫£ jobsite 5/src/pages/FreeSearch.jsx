import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import './FreeSearch.css';


// תמונות רלוונטיות לחיפוש עבודה
const IMAGES = {
  hero: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80',
  interview: 'https://images.unsplash.com/photo-1565843708714-52ecf69ab81f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80',
  workspace: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80',
  success: 'https://images.unsplash.com/photo-1552581234-26160f608093?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80'
};

export default function FreeSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    location: '',
    jobType: '',
    experience: '',
    salary: ''
  });

  const popularSearches = [
    'מפתח Full Stack',
    'מנהל פרויקטים',
    'מעצב UX/UI',
    'דאטה אנליסט',
    'מנהל מוצר'
  ];

  // חברות מובילות עם לוגואים
  const featuredCompanies = [
    { name: 'Google', logo: 'https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_92x30dp.png' },
    { name: 'Microsoft', logo: 'https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RE1Mu3b?ver=5c31&h=40' },
    { name: 'Apple', logo: 'https://www.apple.com/ac/structured-data/images/knowledge_graph_logo.png' },
    { name: 'Meta', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Meta_Platforms_Inc._logo.svg/220px-Meta_Platforms_Inc._logo.svg.png' },
    { name: 'Amazon', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/220px-Amazon_logo.svg.png' },
    { name: 'Intel', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Intel-logo.svg/220px-Intel-logo.svg.png' }
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    // TODO: Implement search logic
    console.log('Searching for:', searchQuery, filters);
  };

  useEffect(() => {
    const buttons = document.querySelectorAll('button, [role="button"], .btn, .tag-button, .filter-button');

    const createRipple = (e) => {
      const button = e.currentTarget;
      const circle = document.createElement('span');
      const diameter = Math.max(button.clientWidth, button.clientHeight);
      const radius = diameter / 2;

      circle.style.width = circle.style.height = `${diameter}px`;
      circle.style.left = `${e.clientX - (button.getBoundingClientRect().left + radius)}px`;
      circle.style.top = `${e.clientY - (button.getBoundingClientRect().top + radius)}px`;
      circle.classList.add('ripple');

      const ripple = button.getElementsByClassName('ripple')[0];
      if (ripple) {
        ripple.remove();
      }

      button.appendChild(circle);
    };

    buttons.forEach(button => {
      button.addEventListener('click', createRipple);
    });

    return () => {
      buttons.forEach(button => {
        button.removeEventListener('click', createRipple);
      });
    };
  }, []);

  return (
    <div className="free-search-page">
      <Navbar />
      <main>
        <div className="hero-section" style={{ backgroundImage: `url(${IMAGES.hero})` }}>
          <div className="hero-overlay" />
          <div className="hero-content">
            <h1>מצא את המשרה המושלמת</h1>
            <p>אלפי משרות חדשות מתווספות כל יום</p>
          </div>
        </div>

        <div className="search-section">
          <h1>חיפוש חופשי</h1>
          <form onSubmit={handleSearch} className="search-form">
            <div className="main-search">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="חפש משרות, חברות או מילות מפתח..."
                className="search-input"
              />
              <button type="submit" className="search-button">חיפוש</button>
            </div>

            <div className="filters">
              <select
                value={filters.location}
                onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                className="filter-select"
              >
                <option value="">בחר איזור</option>
                <option value="תל אביב">תל אביב</option>
                <option value="ירושלים">ירושלים</option>
                <option value="חיפה">חיפה</option>
                <option value="באר שבע">באר שבע</option>
              </select>

              <select
                value={filters.jobType}
                onChange={(e) => setFilters({ ...filters, jobType: e.target.value })}
                className="filter-select"
              >
                <option value="">סוג משרה</option>
                <option value="מלאה">משרה מלאה</option>
                <option value="חלקית">משרה חלקית</option>
                <option value="סטודנט">סטודנט</option>
                <option value="פרילנס">פרילנס</option>
              </select>

              <select
                value={filters.experience}
                onChange={(e) => setFilters({ ...filters, experience: e.target.value })}
                className="filter-select"
              >
                <option value="">ניסיון נדרש</option>
                <option value="ללא">ללא ניסיון</option>
                <option value="1-2">1-2 שנים</option>
                <option value="3-5">3-5 שנים</option>
                <option value="5+">5+ שנים</option>
              </select>

              <select
                value={filters.salary}
                onChange={(e) => setFilters({ ...filters, salary: e.target.value })}
                className="filter-select"
              >
                <option value="">טווח שכר</option>
                <option value="8-12">8,000-12,000 ₪</option>
                <option value="12-16">12,000-16,000 ₪</option>
                <option value="16-20">16,000-20,000 ₪</option>
                <option value="20+">20,000+ ₪</option>
              </select>
            </div>
          </form>
          <div className="popular-searches">
            <h3>חיפושים פופולריים</h3>
            <div className="search-tags">
              {popularSearches.map((search, index) => (
                <button
                  key={index}
                  onClick={() => setSearchQuery(search)}
                  className="tag-button"
                >
                  {search}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="benefits-section">
          <h3 className="section-title">יתרונות האתר</h3>
          <div className="search-benefits">
            <div className="benefit-card">
              <img src={IMAGES.interview} alt="ראיון עבודה" />
              <h3>מצא את המשרה המתאימה</h3>
              <p>אלפי משרות חדשות מתעדכנות מדי יום</p>
            </div>
            <div className="benefit-card">
              <img src={IMAGES.workspace} alt="סביבת עבודה" />
              <h3>סביבת עבודה מושלמת</h3>
              <p>משרות בחברות המובילות במשק</p> 
            </div>
            <div className="benefit-card">
              <img src={IMAGES.success} alt="הצלחה בקריירה" />
              <h3>פתח קריירה מצליחה</h3>
              <p>כלים וטיפים להצלחה בראיונות</p>
            </div>
          </div>
        </div>

        <div className="companies-section">
          <h3 className="section-title">חברות מובילות</h3>
          <div className="company-logos">
            {featuredCompanies.map((company, index) => (
              <div key={index} className="company-logo">
                <img src={company.logo} alt={company.name} className="company-logo-img" />
                <span className="company-name">{company.name}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="categories-section">
          <h3 className="section-title">קטגוריות מבוקשות</h3>
          <div className="category-grid">
            <div className="category-item">
              <i className="fas fa-code" />
              <h4>פיתוח תוכנה</h4>
              <p>2,500+ משרות</p>
            </div>
            <div className="category-item">
              <i className="fas fa-chart-line" />
              <h4>שיווק ומכירות</h4>
              <p>1,800+ משרות</p>
            </div>
            <div className="category-item">
              <i className="fas fa-users" />
              <h4>משאבי אנוש</h4>
              <p>1,200+ משרות</p>
            </div>
            <div className="category-item">
              <i className="fas fa-paint-brush" />
              <h4>עיצוב וקריאייטיב</h4>
              <p>900+ משרות</p>
            </div>
          </div>
        </div>

        <div className="stats-section">
          <h3 className="section-title">נתונים מעניינים</h3>
          <div className="search-stats">
            <div className="stat-item">
              <h4>10,000+</h4>
              <p>משרות פעילות</p>
            </div>
            <div className="stat-item">
              <h4>500+</h4>
              <p>חברות מגייסות</p>
            </div>
            <div className="stat-item">
              <h4>5,000+</h4>
              <p>מועמדים הושמו</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
