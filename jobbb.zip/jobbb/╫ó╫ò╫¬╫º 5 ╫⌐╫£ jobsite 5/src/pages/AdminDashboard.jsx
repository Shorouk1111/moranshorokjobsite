import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [showProfileForm, setShowProfileForm] = useState(false);
  const [profileData, setProfileData] = useState({
    department: '',
    permissions: '',
    phone: ''
  });

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }

    // Fetch user profile
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/auth/profile', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setProfile(data.profile);
        if (data.profile) {
          setProfileData(data.profile);
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  };

  const handleProfileChange = (e) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/admin/profile', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(profileData)
      });

      if (response.ok) {
        alert('פרופיל מנהל נשמר בהצלחה!');
        setShowProfileForm(false);
        fetchProfile();
      } else {
        alert('שגיאה בשמירת הפרופיל');
      }
    } catch (error) {
      console.error('Error saving profile:', error);
      alert('שגיאה בחיבור לשרת');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
  };

  return (
    <div className="admin-dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <div className="header-left">
            <Link to="/" className="home-link">🏠 דף הבית</Link>
            <h1>לוח בקרה - מנהל מערכת</h1>
          </div>
          <div className="user-info">
            <span>שלום, {user?.fullName}</span>
            <button onClick={handleLogout} className="logout-btn">התנתק</button>
          </div>
        </div>
      </header>

      <div className="dashboard-content">
        <div className="sidebar">
          <div className="profile-section">
            <h3>פרופיל מנהל</h3>
            {profile ? (
              <div className="profile-info">
                <p><strong>מחלקה:</strong> {profile.department || 'לא הוזנה'}</p>
                <p><strong>הרשאות:</strong> {profile.permissions || 'לא הוזנו'}</p>
                <p><strong>טלפון:</strong> {profile.phone || 'לא הוזן'}</p>
                <button 
                  onClick={() => setShowProfileForm(true)}
                  className="edit-profile-btn"
                >
                  ערוך פרופיל
                </button>
              </div>
            ) : (
              <div className="no-profile">
                <p>לא נמצא פרופיל מנהל</p>
                <button 
                  onClick={() => setShowProfileForm(true)}
                  className="create-profile-btn"
                >
                  צור פרופיל מנהל
                </button>
              </div>
            )}
          </div>

          <div className="admin-actions">
            <h3>פעולות ניהול</h3>
            <button className="action-btn">נהל משתמשים</button>
            <button className="action-btn">נהל משרות</button>
            <button className="action-btn">נהל חברות</button>
            <button className="action-btn">דוחות מערכת</button>
            <button className="action-btn">הגדרות מערכת</button>
          </div>
        </div>

        <div className="main-content">
          <div className="system-stats">
            <h2>סטטיסטיקות מערכת</h2>
            <div className="stats-grid">
              <div className="stat-card users">
                <h3>סה"כ משתמשים</h3>
                <div className="stat-number">0</div>
                <div className="stat-detail">עובדים: 0 | מעסיקים: 0</div>
              </div>
              <div className="stat-card jobs">
                <h3>משרות פעילות</h3>
                <div className="stat-number">0</div>
                <div className="stat-detail">חדשות השבוע: 0</div>
              </div>
              <div className="stat-card applications">
                <h3>מועמדויות השבוע</h3>
                <div className="stat-number">0</div>
                <div className="stat-detail">אושרו: 0 | נדחו: 0</div>
              </div>
              <div className="stat-card companies">
                <h3>חברות רשומות</h3>
                <div className="stat-number">0</div>
                <div className="stat-detail">פעילות: 0</div>
              </div>
            </div>
          </div>

          <div className="recent-activity">
            <h2>פעילות אחרונה במערכת</h2>
            <div className="activity-list">
              <div className="activity-item">
                <div className="activity-icon">👤</div>
                <div className="activity-content">
                  <p>אין פעילות אחרונה להצגה</p>
                  <span className="activity-time">המערכת מוכנה לשימוש</span>
                </div>
              </div>
            </div>
          </div>

          <div className="system-health">
            <h2>בריאות המערכת</h2>
            <div className="health-indicators">
              <div className="health-item">
                <div className="health-status online"></div>
                <span>שרת בסיס נתונים</span>
              </div>
              <div className="health-item">
                <div className="health-status online"></div>
                <span>שרת אפליקציה</span>
              </div>
              <div className="health-item">
                <div className="health-status online"></div>
                <span>שירותי אימייל</span>
              </div>
              <div className="health-item">
                <div className="health-status online"></div>
                <span>מערכת קבצים</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showProfileForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2>עריכת פרופיל מנהל</h2>
              <button 
                onClick={() => setShowProfileForm(false)}
                className="close-btn"
              >
                ×
              </button>
            </div>
            <form onSubmit={handleProfileSubmit} className="profile-form">
              <div className="form-group">
                <label>מחלקה:</label>
                <input
                  type="text"
                  name="department"
                  value={profileData.department}
                  onChange={handleProfileChange}
                  placeholder="למשל: IT, משאבי אנוש, ניהול"
                />
              </div>
              <div className="form-group">
                <label>הרשאות:</label>
                <textarea
                  name="permissions"
                  value={profileData.permissions}
                  onChange={handleProfileChange}
                  rows="4"
                  placeholder="תאר את ההרשאות והתפקידים שלך במערכת"
                />
              </div>
              <div className="form-group">
                <label>טלפון:</label>
                <input
                  type="tel"
                  name="phone"
                  value={profileData.phone}
                  onChange={handleProfileChange}
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="save-btn">שמור</button>
                <button 
                  type="button" 
                  onClick={() => setShowProfileForm(false)}
                  className="cancel-btn"
                >
                  ביטול
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
