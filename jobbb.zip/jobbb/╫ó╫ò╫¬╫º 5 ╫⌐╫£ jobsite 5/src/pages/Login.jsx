import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaEnvelope, FaLock, FaSignInAlt } from 'react-icons/fa';
import './Login.css';

export default function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // כאן יהיה הטיפול בהתחברות
    console.log('נתוני התחברות:', formData);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h1>התחברות</h1>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">אימייל</label>
            <div className="input-container">
              <FaEnvelope className="input-icon" />
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="הכנס את האימייל שלך"
              />
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="password">סיסמה</label>
            <div className="input-container">
              <FaLock className="input-icon" />
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                placeholder="הכנס את הסיסמה שלך"
              />
            </div>
          </div>
          <div className="form-links">
            <Link to="/forgot-password" className="forgot-password">
              שכחתי סיסמה
            </Link>
          </div>
          <button type="submit" className="submit-btn">
            <FaSignInAlt className="btn-icon" />
            התחבר
          </button>
        </form>
        <div className="register-link">
          עדיין אין לך חשבון?{' '}
          <Link to="/register">הירשם עכשיו</Link>
        </div>
      </div>
    </div>
  );
}
